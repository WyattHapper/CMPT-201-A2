// Group 7, CMPT 201 X01L

typedef struct {
	int x;
	int y;
	char symbol;
} Player;

int splash_screen(void);
void pause_screen(void);
void quit_screen(void);
