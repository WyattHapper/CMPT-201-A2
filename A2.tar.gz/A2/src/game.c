// Group 7, CMPT 201 X01L

#include<stdio.h>
#include<stdlib.h>
#include<ncurses.h>
#include"game.h"

int main(void) {
	int option;	
	initscr();
	noecho();
	while(1) {
		option=splash_screen();
		switch (option) {
			case 'p':
				pause_screen();
				break;
			case 'q':
				quit_screen();
				break;
		}
	}
	return 0;
}

int splash_screen(void) {
	WINDOW *w;
	int choice;
	w=newwin(30,80,0,0);
	wborder(w,'|','|','-','-','+','+','+','+');
	mvwprintw(w,5,13,"-----  |   |  |----    |\\ /|  |---|  -----  |----  |");
	mvwprintw(w,6,13,"  |    |   |  |        | V |  |   |      /  |      |");
	mvwprintw(w,7,13,"  |    |---|  |----    |   |  |---|    /    |----  |");
	mvwprintw(w,8,13,"  |    |   |  |        |   |  |   |  /      |      |");
	mvwprintw(w,9,13,"  |    |   |  |----    |   |  |   |  -----  |----  o");
	mvwprintw(w,13,10,"Intructions: Maneuver through the maze and find the exit.");
	mvwprintw(w,14,8,"Controls: Use the arrow keys to move and the E key to interact.");
	mvwprintw(w,17,23,"Select p to pause the game.");
	mvwprintw(w,18,23,"Select q to exit game.");
	mvwprintw(w,19,23,"Select 1 to play the first level.");
	mvwprintw(w,20,23,"Select 2 to play the second level.");
	wrefresh(w);
	while (1) {
                choice=getchar();
                if (choice=='q' || choice=='1' || choice=='2' || choice=='p')
                        break;
        }
	return choice;
}

void pause_screen(void) {
	WINDOW *w;
	int choice;
	w=newwin(30,80,0,0);
	wborder(w,'|','|','-','-','+','+','+','+');
	mvwprintw(w,12,18,"|---   |---|  |   |  -----  |----  |---   ");
	mvwprintw(w,13,18,"|   |  |   |  |   |  \\      |      |   \\  ");
	mvwprintw(w,14,18,"|---   |---|  |   |    \\    |----  |   |  ");
	mvwprintw(w,15,18,"|      |   |  |   |      \\  |      |   /  ");
	mvwprintw(w,16,18,"|      |   |  |---|  -----  |----  |---   ");
	wrefresh(w);
	while(1) {
		choice=getchar();
		if (choice=='p')
			break;
	}
}

void quit_screen(void) {
	WINDOW *w;
        int choice;
        w=newwin(30,80,0,0);
        wborder(w,'|','|','-','-','+','+','+','+');
        mvwprintw(w,10,23,"|---|  |   |  -----  -----  -----");
        mvwprintw(w,11,23,"|   |  |   |    |      |        |");
        mvwprintw(w,12,23,"|   |  |   |    |      |      --|");
        mvwprintw(w,13,23,"|  \\|  |   |    |      |      |");
        mvwprintw(w,14,23,"|---\\  |---|  -----    |      o");
	mvwprintw(w,17,25,"Press y for yes and n for no.");
	wrefresh(w);
	while(1) {
		choice=getchar();
		if (choice=='n')
			break;
		else if (choice=='y') {
			endwin();
			exit(EXIT_SUCCESS);
		}
	}
}
